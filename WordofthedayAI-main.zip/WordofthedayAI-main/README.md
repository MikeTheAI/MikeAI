# WordofthedayAI
A Twitter bot that effortlessly delivers a daily "word of the day" to your feed.

[<img alt="x.com/WordofthedayAI" width="200" src="https://github.com/user-attachments/assets/30e09a7e-9205-4b14-aaac-274aea093205" />](https://x.com/wordofthedayAI)
